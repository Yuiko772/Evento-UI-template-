
package com.example.whatsappstyleui.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = androidx.compose.ui.graphics.Color(0xFF075E54),
    secondary = androidx.compose.ui.graphics.Color(0xFF128C7E),
    tertiary = androidx.compose.ui.graphics.Color(0xFF25D366)
)

@Composable
fun WhatsAppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = androidx.compose.material3.Typography(),
        content = content
    )
}
