
package com.example.whatsappstyleui.ui.screens

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp

@Composable
fun MainScreen() {
    var selectedTab by remember { mutableStateOf(0) }

    val tabs = listOf("Chat", "Status", "Panggilan")

    Scaffold(
        topBar = {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color(0xFF075E54),
                contentColor = Color.White
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 16.sp,
                                color = if (selectedTab == index) Color.White else Color.LightGray
                            )
                        }
                    )
                }
            }
        }
    ) { padding ->
        when (selectedTab) {
            0 -> ChatScreen(Modifier.fillMaxSize().padding(padding))
            1 -> StatusScreen(Modifier.fillMaxSize().padding(padding))
            2 -> CallScreen(Modifier.fillMaxSize().padding(padding))
        }
    }
}
